﻿Imports System.Data.SqlClient
Imports System.Web.Configuration

Public Class page1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Protected Sub btnclick() Handles btn1.Click

        'connection to the server
        'source by dekstop
        'myconnection variable

        Dim connectionString As String = WebConfigurationManager.ConnectionStrings("MyConnectionString").ConnectionString
        Dim myConnection As New SqlConnection(connectionString)


        'instance of sql command class
        Dim sqlCommand As New SqlCommand

        'local variable of sqlconnection
        sqlCommand.Connection = myConnection
        sqlCommand.CommandText = "Select * from product_t where product_description like '%"
        sqlCommand.CommandText &= tb1.Text & "' or product_description like '" + tb1.Text + "%'"

        Try
            myConnection.Open()
            Dim dr As SqlDataReader
            dr = sqlCommand.ExecuteReader()
            dr.Read()
            'product description
            Dim pd As String = dr("product_description")
            'standard price
            Dim sp As String = dr("standard_price")
            myConnection.Close()

            Dim li As New ListItem


            'list-box displaying 
            'the text and the prices
            li.Text = pd + " with a price tag of " + sp

            lb1.Items.Add(li)


            'in else case if the product is not found
            'display error
        Catch ex As Exception
            lbl2.Text = "Error! not found"
        End Try





    End Sub

End Class