﻿Imports System.Data.SqlClient
Imports System.Web.Configuration

Public Class page2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub button_1() Handles btn1.Click

        'my connection variable  
        Dim connectionString As String = WebConfigurationManager.ConnectionStrings("MyConnectionString").ConnectionString
        Dim myConnection As New SqlConnection(connectionString)


        'instance of sql class
        Dim sqlCommand As New SqlCommand
        sqlCommand.Connection = myConnection

        'db query 
        sqlCommand.CommandText = "Select * from customer_t where customer_name like '%"
        sqlCommand.CommandText &= tb1.Text & "' or customer_name like '" + tb1.Text + "%'"

        Try
            myConnection.Open()

            'class system data
            Dim dr As SqlDataReader
            dr = sqlCommand.ExecuteReader()
            dr.Read()

            'displaying columns of the customer table 
            'relevent infor
            Dim C_N As String = dr("customer_name")
            Dim C_ID As String = dr("customer_id")
            Dim C_CTY As String = dr("customer_city")
            myConnection.Close()




            Dim li As New ListItem
            li.Text = "The id " + C_ID + " is of " + C_N + " belongs to city" + C_CTY



            lb1.Items.Add(li)
        Catch ex As Exception
            lbl2.Text = "Customer Dont exist in our database!"
        End Try





    End Sub

End Class