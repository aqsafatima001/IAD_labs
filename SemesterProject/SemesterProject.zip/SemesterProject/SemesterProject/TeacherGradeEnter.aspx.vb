﻿Imports System.Data.SqlClient

Public Class TeacherGradeEnter
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ' check if user is logged in
            If Session("username") Is Nothing Then
                Response.Redirect("login.aspx")
            End If
        End If
    End Sub

    Protected Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click

        Dim selectedSemester As Integer = Integer.Parse(Request.Form("semesterSelect"))

        ' retrieve course ids for the given semester
        Dim courseIds As New List(Of Integer)
        Dim connString As String = "Data Source=LAPTOP-G5TDHLRV\SQL_IAD;Initial Catalog=SemesterProject;Integrated Security=True"
        Using conn As New SqlConnection(connString)
            conn.Open()
            Dim query As String = "SELECT DISTINCT c.course_id FROM course c INNER JOIN student_course sc ON c.course_id = sc.course_id WHERE c.course_sem = @semester"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@semester", selectedSemester)
                Dim reader As SqlDataReader = cmd.ExecuteReader()
                While reader.Read()
                    courseIds.Add(reader.GetInt32(0))
                End While
                reader.Close()
            End Using
        End Using

        ' retrieve student names for the given course ids
        Dim studentNames As New List(Of String)
        Using conn As New SqlConnection(connString)
            conn.Open()
            Dim query As String = "SELECT DISTINCT s.username FROM student_users s INNER JOIN student_course sc ON s.username = sc.username WHERE sc.course_id IN (" + String.Join(",", courseIds) + ")"
            Using cmd As New SqlCommand(query, conn)
                Dim reader As SqlDataReader = cmd.ExecuteReader()
                While reader.Read()
                    studentNames.Add(reader.GetString(0))
                End While
                reader.Close()
            End Using
        End Using

        ' bind the student names to the list box
        'lstStudents.DataSource = studentNames
        'lstStudents.DataBind()
    End Sub



End Class