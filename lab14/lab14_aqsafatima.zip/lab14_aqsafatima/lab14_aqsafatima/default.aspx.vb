﻿Public Class _default
    Inherits System.Web.UI.Page

    Protected WithEvents cmdSubmit As Button
    Protected WithEvents cmdCancel As Button
    Protected lblMessage As Label

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        ' Retrieve the controls from the page markup
        cmdSubmit = DirectCast(FindControl("cmdSubmit"), Button)
        cmdCancel = DirectCast(FindControl("cmdCancel"), Button)
        lblMessage = DirectCast(FindControl("lblMessage"), Label)
    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        If Page.IsValid Then
            lblMessage.Text = "This is a valid form."
        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
        lblMessage.Text = "No attempt was made to validate this form."
    End Sub

End Class